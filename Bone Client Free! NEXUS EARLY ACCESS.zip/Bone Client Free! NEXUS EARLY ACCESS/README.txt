
Thank You For Using Bone Client Free!

This menu was made using Malachi template so credits to Malachi.
And thanks to Appl3GT for most of the code!

WARNING: I am not responsible for any bans caused by the use of this menu.
If you got banned please report to my discord in #ban-reports in the free menu section.

Have Fun!